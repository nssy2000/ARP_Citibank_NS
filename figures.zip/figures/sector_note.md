# Sector dispersion: human arm vs model arm

**Purpose:** Determine whether the qualitative pattern (humans hold heavily in
energy, trade heavily in technology and materials) holds under any defensible
filter on the human export.

**Source (human):** 
**Source (model):** 
  (Set A, LLM arm, dispersion cut)

Sector mapping: GICS-like labels in the human export are collapsed to the
broad SECTORS dict categories used in the model analysis: Consumer Discretionary
and Consumer Staples both map to Consumer, Information Technology maps to
Technology, Health Care maps to Healthcare.

score_std is population standard deviation. HOLD rate is the fraction of
decisions that are HOLD (not BUY or SELL).

## Model arm (Set A, LLM, N=233)

| Sector | n | score_std | HOLD rate |
|---|---|---|---|
| Communication Services | 19 | 0.1768 | 42% |
| Consumer | 82 | 0.2661 | 37% |
| Financials | 49 | 0.1845 | 43% |
| Healthcare | 18 | 0.2374 | 39% |
| Industrials | 26 | 0.2349 | 35% |
| Materials | 3 | 0.1266 | 33% |
| Technology | 36 | 0.1533 | 31% |

## Human arm — filter A: first_rater=YES, info_set=full, in_llm_universe=YES

| Sector | n | score_std | HOLD rate |
|---|---|---|---|
| Communication Services | 11 | 0.2416 | 18% |
| Consumer | 37 | 0.4078 | 30% |
| Financials | 37 | 0.3133 | 22% |
| Healthcare | 7 | 0.4617 | 14% |
| Industrials | 17 | 0.4328 | 18% |
| Technology | 16 | 0.2856 | 6% |

## Human arm — filter B: all raters, info_set=full, in_llm_universe=YES

| Sector | n | score_std | HOLD rate |
|---|---|---|---|
| Communication Services | 18 | 0.3078 | 17% |
| Consumer | 37 | 0.4078 | 30% |
| Financials | 37 | 0.3133 | 22% |
| Healthcare | 7 | 0.4617 | 14% |
| Industrials | 17 | 0.4328 | 18% |
| Technology | 16 | 0.2856 | 6% |

## Human arm — filter C: first_rater=YES, info_set=full, no llm_universe filter

| Sector | n | score_std | HOLD rate |
|---|---|---|---|
| Communication Services | 11 | 0.2416 | 18% |
| Consumer | 46 | 0.3821 | 30% |
| Energy | 15 | 0.2344 | 60% |
| Financials | 39 | 0.3103 | 26% |
| Healthcare | 7 | 0.4617 | 14% |
| Industrials | 17 | 0.4328 | 18% |
| Technology | 20 | 0.2593 | 5% |
| Utilities | 13 | 0.2466 | 38% |

## Human arm — filter D: all raters, all info sets, no filters

| Sector | n | score_std | HOLD rate |
|---|---|---|---|
| Communication Services | 38 | 0.3620 | 16% |
| Consumer | 127 | 0.3708 | 33% |
| Energy | 27 | 0.2211 | 67% |
| Financials | 79 | 0.3038 | 27% |
| Healthcare | 26 | 0.4113 | 8% |
| Industrials | 42 | 0.3710 | 26% |
| Materials | 6 | 0.2357 | 33% |
| Technology | 62 | 0.4320 | 11% |
| Utilities | 13 | 0.2466 | 38% |

## Human arm — filter E: first_rater=YES, all info sets, in_llm_universe=YES

| Sector | n | score_std | HOLD rate |
|---|---|---|---|
| Communication Services | 26 | 0.3792 | 15% |
| Consumer | 89 | 0.3869 | 31% |
| Financials | 63 | 0.3252 | 19% |
| Healthcare | 23 | 0.4175 | 4% |
| Industrials | 35 | 0.3890 | 26% |
| Materials | 3 | 0.1247 | 67% |
| Technology | 44 | 0.4465 | 9% |

## Qualitative pattern check

The question is whether humans hold heavily in Energy and trade heavily in
Technology (and Materials where available).

Energy only appears under filters C and D (the ones without the
in_llm_universe=YES restriction, since Energy issuers are all in Set B,
not in the N=233 Set A LLM universe).

**Filter A: first_rater=YES, info_set=full, in_llm_universe=YES:**
  Energy: not present (filtered out)
  Technology: n=16, HOLD=6%
  Materials: not present

**Filter B: all raters, info_set=full, in_llm_universe=YES:**
  Energy: not present (filtered out)
  Technology: n=16, HOLD=6%
  Materials: not present

**Filter C: first_rater=YES, info_set=full, no llm_universe filter:**
  Energy: n=15, HOLD=60%
  Technology: n=20, HOLD=5%
  Materials: not present
  Energy vs Technology HOLD gap: 55pp -> pattern holds: YES

**Filter D: all raters, all info sets, no filters:**
  Energy: n=27, HOLD=67%
  Technology: n=62, HOLD=11%
  Materials: n=6, HOLD=33%
  Energy vs Technology HOLD gap: 55pp -> pattern holds: YES

**Filter E: first_rater=YES, all info sets, in_llm_universe=YES:**
  Energy: not present (filtered out)
  Technology: n=44, HOLD=9%
  Materials: n=3, HOLD=67%

