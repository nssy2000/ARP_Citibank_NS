#!/usr/bin/env python3
"""
Generate all figures for the ARP report.
READ-ONLY access to all project data; writes only to figures/.

Usage:
    python figures/plot_all_figures.py
"""

import os, sys, json, csv, glob
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
from matplotlib.patches import FancyBboxPatch
from pathlib import Path

# Add project root to path for blend imports
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# ── Paths ──────────────────────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent.parent
SUMMARY = ROOT / "outputs" / "global" / "summary"
FIGURES = ROOT / "figures"
FIGURES.mkdir(exist_ok=True)

# ── Style ──────────────────────────────────────────────────────────────────
NAVY   = "#013B70"
RED    = "#D9261C"
GREY   = "#808080"
LTGREY = "#C0C0C0"
GREEN  = "#2E7D32"
GOLD   = "#DAA520"

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Nimbus Roman", "DejaVu Serif"],
    "font.size": 10,
    "axes.titlesize": 11,
    "axes.labelsize": 10,
    "xtick.labelsize": 9,
    "ytick.labelsize": 9,
    "legend.fontsize": 8,
    "figure.dpi": 300,
    "savefig.dpi": 300,
    "savefig.bbox": "tight",
    "axes.spines.top": False,
    "axes.spines.right": False,
})

FIG_WIDTH_CM = 11
FIG_WIDTH = FIG_WIDTH_CM / 2.54  # inches

def save(fig, name):
    """Save as both PDF (vector) and PNG (300 dpi)."""
    fig.savefig(FIGURES / f"{name}.pdf", format="pdf")
    fig.savefig(FIGURES / f"{name}.png", format="png")
    plt.close(fig)
    print(f"  ✓ {name}.pdf + .png")


# ═══════════════════════════════════════════════════════════════════════════
# HELPERS: load data
# ═══════════════════════════════════════════════════════════════════════════

def load_returns_matrix():
    """Load returns_matrix.csv, return list of dicts."""
    rows = []
    with open(SUMMARY / "returns_matrix.csv") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)
    return rows

def load_calibration_csv():
    """Load global_outcome_calibration_phase2.csv."""
    rows = []
    with open(SUMMARY / "global_outcome_calibration_phase2.csv") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)
    return rows

def load_excluded_ids():
    """Load the 25 worksheet-contaminated document_ids."""
    ids = set()
    with open(SUMMARY / "supplementary_rescore_25.csv") as f:
        lines = [l for l in f if not l.startswith("#")]
        reader = csv.DictReader(lines)
        for r in reader:
            ids.add(r["document_id"])
    return ids

def clean_universe(returns_rows, calibration_rows):
    """Filter to N=233 clean events. Returns list of merged dicts."""
    excluded_ws = load_excluded_ids()
    # Build calibration lookup
    cal_map = {r["document_id"]: r for r in calibration_rows}

    clean = []
    for r in returns_rows:
        doc_id = r["document_id"]
        if r.get("timing_excluded", "NO") == "YES":
            continue
        if doc_id in excluded_ws:
            continue
        if doc_id == "SPOT_FQ1_2026":
            continue
        if doc_id in cal_map:
            merged = {**r, **cal_map[doc_id]}
            clean.append(merged)
    return clean

def load_holding_curve():
    """Load ext2_holding_curve.csv."""
    rows = []
    with open(SUMMARY / "ext2_holding_curve.csv") as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            if line.startswith("horizon"):
                headers = line.strip().split(",")
                continue
            vals = line.strip().split(",")
            rows.append(dict(zip(headers, vals)))
    return rows

def load_latency_jsonl():
    """Load all first_run_costs.jsonl files, extract latency_seconds."""
    latencies = []
    for jf in glob.glob(str(ROOT / "outputs" / "p2_*" / "logs" / "first_run_costs.jsonl")):
        with open(jf) as f:
            for line in f:
                try:
                    rec = json.loads(line)
                    if rec.get("status") == "success" and rec.get("latency_seconds") is not None:
                        latencies.append(float(rec["latency_seconds"]))
                except (json.JSONDecodeError, KeyError):
                    pass
    return np.array(latencies)


# ═══════════════════════════════════════════════════════════════════════════
# F1: SAMPLE FUNNEL
# ═══════════════════════════════════════════════════════════════════════════

def plot_f1():
    """F1: Sample funnel from 268 → 233 → 146 → 95 → 62."""
    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 1.1))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 12)
    ax.axis("off")

    # Funnel boxes (top to bottom)
    levels = [
        ("Total scored events", "N = 268", 11.0, NAVY),
        ("Clean universe", "N = 233", 8.8, NAVY),
        ("Model traded\n(BUY or SELL)", "N = 146", 6.6, NAVY),
        ("Graded\n(|ret| > 2%)", "N = 95", 4.4, NAVY),
        ("Correct", "N = 62\n(65.3%)", 2.2, GREEN),
    ]

    box_h = 1.5
    for label, count, y, color in levels:
        # Width narrows with funnel
        w = 3.0 + (y / 11.0) * 4.0
        x = 5.0 - w / 2
        rect = FancyBboxPatch((x, y), w, box_h, boxstyle="round,pad=0.1",
                              facecolor=color, edgecolor="white", alpha=0.85)
        ax.add_patch(rect)
        ax.text(5.0, y + box_h / 2 + 0.15, label, ha="center", va="center",
                color="white", fontsize=8, fontweight="bold")
        ax.text(5.0, y + box_h / 2 - 0.35, count, ha="center", va="center",
                color="white", fontsize=9)

    # Right-side exclusion annotations
    excl = [
        (10.0, "−25 worksheet", "contamination"),
        (9.8, "−1 SPOT", "misattribution"),
        (9.6, "−9 timing", "non-US issuers"),
        (7.4, "−87 HOLD", "no trade"),
        (5.2, "−51 flat", "|ret| ≤ 2%"),
    ]
    for y, line1, line2 in excl:
        ax.text(8.8, y, line1, ha="left", va="center", fontsize=7, color=RED)
        ax.text(8.8, y - 0.3, line2, ha="left", va="center", fontsize=6.5, color=GREY)

    # HOLD limb (branching from traded level)
    ax.annotate("", xy=(8.0, 7.0), xytext=(6.5, 7.4),
                arrowprops=dict(arrowstyle="->", color=GREY, lw=1))
    ax.text(8.2, 7.0, "87 HOLD\n(37.3%)", ha="left", va="center",
            fontsize=7, color=GREY)
    # of which 52 graded
    ax.text(8.2, 6.4, "52 graded moves\nmissed by HOLD", ha="left", va="center",
            fontsize=6.5, color=GREY, style="italic")

    ax.set_title("Figure 1: Sample funnel", fontsize=11, fontweight="bold", pad=10)
    save(fig, "F1_sample_funnel")

# ═══════════════════════════════════════════════════════════════════════════
# F2: RHO DECAY + MEAN NET DECAY (two stacked panels)
# ═══════════════════════════════════════════════════════════════════════════

def plot_f2():
    """F2: Spearman rho decay and mean net per trade by horizon."""
    hc = load_holding_curve()
    horizons = ["overnight", "1d", "3d", "5d", "10d"]
    x_vals = [0, 1, 3, 5, 10]

    rhos = [float(r["rank_correlation"]) for r in hc]
    pvals = [float(r["rho_pvalue"]) for r in hc]
    means = [float(r["mean_net_per_trade"]) * 100 for r in hc]
    ci_lo = [float(r["bootstrap_ci_low"]) * 100 for r in hc]
    ci_hi = [float(r["bootstrap_ci_high"]) * 100 for r in hc]

    # Fisher-z 90% CI for rho
    n = 233
    import math
    z_crit = 1.645
    rho_ci_lo, rho_ci_hi = [], []
    for rho in rhos:
        z = 0.5 * math.log((1 + rho) / (1 - rho))
        se = 1.0 / math.sqrt(n - 3)
        lo_z = z - z_crit * se
        hi_z = z + z_crit * se
        rho_ci_lo.append((math.exp(2 * lo_z) - 1) / (math.exp(2 * lo_z) + 1))
        rho_ci_hi.append((math.exp(2 * hi_z) - 1) / (math.exp(2 * hi_z) + 1))

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(FIG_WIDTH, FIG_WIDTH * 1.3),
                                    sharex=True, gridspec_kw={"hspace": 0.15})

    # Top panel: rho
    ax1.fill_between(x_vals, rho_ci_lo, rho_ci_hi, alpha=0.15, color=NAVY)
    ax1.plot(x_vals, rhos, "o-", color=NAVY, markersize=5, lw=1.5)
    ax1.axhline(0, color=GREY, lw=0.5, ls="--")
    for i, (x, rho, p) in enumerate(zip(x_vals, rhos, pvals)):
        sig = "***" if p < 0.001 else "**" if p < 0.01 else "*" if p < 0.05 else ""
        ax1.annotate(f"{rho:.3f}{sig}", (x, rho), textcoords="offset points",
                     xytext=(0, 8), ha="center", fontsize=7, color=NAVY)
    ax1.set_ylabel("Spearman ρ")
    ax1.set_title("Figure 2: Signal decay by holding horizon (N = 233)",
                   fontsize=10, fontweight="bold")
    ax1.text(0.98, 0.95, "Fisher-z 90% CI\n(computed in plot script)", transform=ax1.transAxes,
             ha="right", va="top", fontsize=6.5, color=GREY)

    # Bottom panel: mean net per trade
    err_lo = [m - l for m, l in zip(means, ci_lo)]
    err_hi = [h - m for m, h in zip(means, ci_hi)]
    ax2.errorbar(x_vals, means, yerr=[err_lo, err_hi], fmt="s-",
                 color=RED, markersize=5, lw=1.5, capsize=3)
    ax2.axhline(0, color=GREY, lw=0.5, ls="--")
    for i, (x, m) in enumerate(zip(x_vals, means)):
        ax2.annotate(f"{m:.2f}%", (x, m), textcoords="offset points",
                     xytext=(0, -12), ha="center", fontsize=7, color=RED)
    ax2.set_xlabel("Holding horizon (trading days)")
    ax2.set_ylabel("Mean net per trade (%)")
    ax2.text(0.98, 0.95, "Bootstrap 90% CI", transform=ax2.transAxes,
             ha="right", va="top", fontsize=7, color=GREY)
    # Mark where CI crosses zero
    ax2.annotate("CI crosses zero", xy=(4, 0), xytext=(6, 1.0),
                 fontsize=7, color=GREY, style="italic",
                 arrowprops=dict(arrowstyle="->", color=GREY, lw=0.7))

    ax2.set_xticks(x_vals)
    ax2.set_xticklabels(["ON", "1d", "3d", "5d", "10d"])

    save(fig, "F2_rho_decay")


# ═══════════════════════════════════════════════════════════════════════════
# F3: ACCURACY VS BAND WIDTH
# ═══════════════════════════════════════════════════════════════════════════

def plot_f3():
    """F3: Directional accuracy by grading-band width (convention a, strict >)."""
    # Pre-computed from returns_matrix.csv + calibration CSV
    # Convention (a): strict > inequality, verified to reproduce all known data points
    # The 5% cell: 52 graded, 71.2% (report's 53/71.7% confirmed wrong; user will fix)

    # Load and compute
    ret_rows = load_returns_matrix()
    cal_rows = load_calibration_csv()
    events = clean_universe(ret_rows, cal_rows)

    bands = [0.0, 0.01, 0.02, 0.03, 0.05, 0.10]
    band_labels = ["0%", "1%", "2%", "3%", "5%", "10%"]

    results = []
    for band in bands:
        n_graded = 0
        n_correct = 0
        for e in events:
            ret = float(e["ret_overnight"])
            signal = e.get("blend_predicted_signal_default", "HOLD")
            if signal == "HOLD":
                continue
            if abs(ret) > band:
                n_graded += 1
                if (signal == "BUY" and ret > 0) or (signal == "SELL" and ret < 0):
                    n_correct += 1
        acc = n_correct / n_graded if n_graded > 0 else 0
        results.append((band, n_graded, n_correct, acc))

    n_graded = [r[1] for r in results]
    accuracies = [r[3] * 100 for r in results]

    fig, ax1 = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.7))
    ax2 = ax1.twinx()

    # Accuracy bars
    bars = ax1.bar(range(len(bands)), accuracies, color=NAVY, alpha=0.8, width=0.6)
    ax1.set_ylabel("Directional accuracy (%)", color=NAVY)
    ax1.set_ylim(50, 92)

    # n_graded line
    ax2.plot(range(len(bands)), n_graded, "D-", color=RED, markersize=5, lw=1.2)
    ax2.set_ylabel("Graded events (n)", color=RED)

    # Annotate bars
    for i, (acc, n) in enumerate(zip(accuracies, n_graded)):
        ax1.text(i, acc + 0.8, f"{acc:.1f}%", ha="center", fontsize=7, color=NAVY)
        ax2.text(i, n + 2, f"n={n}", ha="center", fontsize=6.5, color=RED)

    # Mark the pre-registered 2% band
    ax1.axvline(2, color=GREY, ls="--", lw=0.7, alpha=0.5)
    ax1.text(2.15, 82, "pre-registered", fontsize=6.5, color=GREY, style="italic", rotation=90, va="top")

    ax1.set_xticks(range(len(bands)))
    ax1.set_xticklabels(band_labels)
    ax1.set_xlabel("Grading band (±)")
    ax1.set_title("Figure 3: Accuracy vs grading-band width\n(N = 233, convention a: strict >)",
                   fontsize=10, fontweight="bold")

    save(fig, "F3_band_sensitivity")


# ═══════════════════════════════════════════════════════════════════════════
# F4: SELECTIVITY VS COVERAGE
# ═══════════════════════════════════════════════════════════════════════════

def plot_f4():
    """F4: Selectivity (62/95=65.3%) vs Coverage (62/147=42.2%) with floors."""
    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.65))

    metrics = ["Selectivity\n(HOLD-excluded)", "Coverage\n(HOLD = wrong)"]
    values = [65.3, 42.2]
    floors = [54.7, 54.4]
    denoms = [95, 147]
    correct = [62, 62]

    x = np.arange(len(metrics))
    w = 0.35

    bars = ax.bar(x, values, w, color=NAVY, alpha=0.85, label="Model accuracy")
    # Floor markers
    for i in range(len(metrics)):
        ax.plot([x[i] - w/2, x[i] + w/2], [floors[i], floors[i]],
                color=RED, lw=2, ls="--")
        ax.text(x[i] + w/2 + 0.05, floors[i], f"floor {floors[i]:.1f}%",
                fontsize=7, color=RED, va="center")

    # Annotate
    for i in range(len(metrics)):
        ax.text(x[i], values[i] + 1.5,
                f"{correct[i]}/{denoms[i]} = {values[i]:.1f}%",
                ha="center", fontsize=8, color=NAVY, fontweight="bold")

    ax.set_xticks(x)
    ax.set_xticklabels(metrics, fontsize=9)
    ax.set_ylabel("Accuracy (%)")
    ax.set_ylim(0, 80)
    ax.set_title("Figure 4: Selectivity vs coverage accuracy\n(same 62 correct calls, different denominators; N = 233)",
                 fontsize=9, fontweight="bold")
    ax.text(0.5, -0.18, "Pre-registered ±2% overnight band",
            transform=ax.transAxes, ha="center", fontsize=7, color=GREY, style="italic")

    save(fig, "F4_selectivity_vs_coverage")


# ═══════════════════════════════════════════════════════════════════════════
# F5: RETURN DISTRIBUTION
# ═══════════════════════════════════════════════════════════════════════════

def plot_f5():
    """F5: Distribution of per-trade net returns (146 trades)."""
    ret_rows = load_returns_matrix()
    cal_rows = load_calibration_csv()
    events = clean_universe(ret_rows, cal_rows)

    # Compute net returns for traded events
    nets = []
    for e in events:
        signal = e.get("blend_predicted_signal_default", "HOLD")
        if signal == "HOLD":
            continue
        ret = float(e["ret_overnight"])
        cost = 0.001  # 10bps round-trip
        if signal == "BUY":
            net = ret - cost
        else:  # SELL
            net = -ret - cost
        nets.append(net * 100)

    nets = np.array(nets)

    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.7))

    # 6 buckets
    bins = np.array([-15, -10, -5, 0, 5, 10, 15])
    n, bins_out, patches = ax.hist(nets, bins=bins, color=NAVY, alpha=0.8,
                                    edgecolor="white", lw=0.5)

    # Shade losing trades
    for i, patch in enumerate(patches):
        if bins[i + 1] <= 0:
            patch.set_facecolor(RED)
            patch.set_alpha(0.7)

    # Mean and median
    mean_net = np.mean(nets)
    median_net = np.median(nets)
    ax.axvline(mean_net, color=NAVY, ls="--", lw=1.2, label=f"Mean = {mean_net:.2f}%")
    ax.axvline(median_net, color=GOLD, ls="-.", lw=1.2, label=f"Median = {median_net:.2f}%")

    ax.set_xlabel("Net return per trade (%)")
    ax.set_ylabel("Count")
    ax.legend(loc="upper right", fontsize=7)
    ax.set_title(f"Figure 5: Per-trade return distribution (n = {len(nets)} trades)",
                 fontsize=10, fontweight="bold")
    ax.text(0.02, 0.95, f"Losing trades: {(nets < 0).sum()}/{len(nets)}\n({(nets < 0).mean()*100:.0f}%)",
            transform=ax.transAxes, fontsize=7, color=RED, va="top")

    save(fig, "F5_return_distribution")


# ═══════════════════════════════════════════════════════════════════════════
# F6: BASELINE FRONTIER
# ═══════════════════════════════════════════════════════════════════════════

def plot_f6():
    """F6: Baseline frontier (4 methods, eval split, coverage convention)."""
    # From frontier_table.csv
    methods = ["Majority\nHOLD", "Loughran-\nMcDonald", "FinBERT", "Deployed\nmodel"]
    accs = [54.6, 15.1, 34.5, 42.9]  # FinBERT: 34.5% (41/119, corrected from 34.4%)
    ci_lo = [47.1, 10.1, 27.7, 35.3]
    ci_hi = [62.2, 21.0, 42.0, 50.4]
    trades = [0, 59, 147, 111]
    trade_rates = [f"0/186", f"59/186", f"147/186", f"111/186"]
    n_correct = ["65/119", "18/119", "41/119", "51/119"]

    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.7))

    x = np.arange(len(methods))
    colors = [GREY, LTGREY, GOLD, NAVY]

    bars = ax.bar(x, accs, 0.55, color=colors, alpha=0.85, edgecolor="white")

    # CIs
    for i in range(len(methods)):
        ax.plot([x[i], x[i]], [ci_lo[i], ci_hi[i]], color="black", lw=1.2)
        ax.plot([x[i]-0.08, x[i]+0.08], [ci_lo[i], ci_lo[i]], color="black", lw=1.2)
        ax.plot([x[i]-0.08, x[i]+0.08], [ci_hi[i], ci_hi[i]], color="black", lw=1.2)

    # Majority floor line
    ax.axhline(54.6, color=RED, ls="--", lw=0.8, alpha=0.6)
    ax.text(3.5, 55.5, "majority floor", fontsize=7, color=RED, style="italic")

    # Annotate
    for i in range(len(methods)):
        ax.text(x[i], accs[i] + 2.5, f"{n_correct[i]}\n{accs[i]:.1f}%",
                ha="center", fontsize=7, fontweight="bold")
        ax.text(x[i], -4, f"trades: {trade_rates[i]}",
                ha="center", fontsize=6, color=GREY, rotation=0)

    ax.set_xticks(x)
    ax.set_xticklabels(methods, fontsize=8)
    ax.set_ylabel("Coverage accuracy (%)")
    ax.set_ylim(-7, 70)
    ax.set_title("Figure 6: Baseline frontier (eval split, N = 186, 119 graded)\nCoverage convention: HOLD on moved event = wrong",
                 fontsize=9, fontweight="bold")
    ax.text(0.5, -0.22, "90% bootstrap CIs; FinBERT corrected to 34.5% (41/119, not 34.4% as truncated in source file)",
            transform=ax.transAxes, ha="center", fontsize=6, color=GREY, style="italic")

    save(fig, "F6_baseline_frontier")


# ═══════════════════════════════════════════════════════════════════════════
# F7: MDE VS OBSERVED DIFFERENCE (6 comparisons from Table 3)
# ═══════════════════════════════════════════════════════════════════════════

def plot_f7():
    """F7: MDE vs observed effect size for 6 Table 3 comparisons."""
    # 6 comparisons from results_three_sets.csv and surviving_findings.md
    comparisons = [
        # (label, observed_pp, mde_pp, significant)
        ("Selectivity\nvs floor\n(n=95)", 10.5, 10.8, False),
        ("Cross-issuer\nLOO\n(n=233)", 0.0, 20.8, False),  # biggest single-ticker is CMG
        ("Press vs\nfull bundle\n(n=66 incl.)", -6.8, 12.0, False),
        ("Prepared vs\nfull bundle\n(n=62 incl.)", -4.0, 12.0, False),
        ("Q&A vs\nfull bundle\n(n=66 incl.)", -5.3, 12.0, False),
        ("Walk-forward\nOOS vs floor\n(n=25)", 14.6, 30.0, False),
    ]

    labels = [c[0] for c in comparisons]
    observed = [c[1] for c in comparisons]
    mde = [c[2] for c in comparisons]

    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.8))

    x = np.arange(len(comparisons))

    # MDE bands (indifference zone)
    for i in range(len(comparisons)):
        ax.fill_between([i - 0.3, i + 0.3], [-mde[i], -mde[i]], [mde[i], mde[i]],
                        color=LTGREY, alpha=0.3)
        ax.plot([i - 0.3, i + 0.3], [mde[i], mde[i]], color=GREY, lw=0.7, ls=":")
        ax.plot([i - 0.3, i + 0.3], [-mde[i], -mde[i]], color=GREY, lw=0.7, ls=":")

    # Observed effects
    colors_obs = [NAVY if abs(o) < m else GREEN for o, m in zip(observed, mde)]
    ax.scatter(x, observed, c=colors_obs, s=60, zorder=5, marker="D")

    # Annotate observed values
    for i, (obs, m) in enumerate(zip(observed, mde)):
        offset = 8 if obs >= 0 else -12
        ax.annotate(f"{obs:+.1f}pp", (i, obs), textcoords="offset points",
                    xytext=(0, offset), ha="center", fontsize=7, color=colors_obs[i])

    ax.axhline(0, color="black", lw=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=7)
    ax.set_ylabel("Effect size (pp)")
    ax.set_title("Figure 7: Observed effect vs minimum detectable effect\n(shaded = indifference zone at 80% power, α = 0.10)",
                 fontsize=9, fontweight="bold")

    # Legend
    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], marker="D", color="w", markerfacecolor=NAVY, markersize=7, label="Inside MDE (underpowered)"),
        plt.Rectangle((0,0), 1, 1, fc=LTGREY, alpha=0.3, label="MDE band (±)")
    ]
    ax.legend(handles=legend_elements, loc="upper right", fontsize=7)

    save(fig, "F7_mde_vs_observed")


# ═══════════════════════════════════════════════════════════════════════════
# F8: BUY/SELL ASYMMETRY (4 bars: human BUY, human SELL, LLM BUY, LLM SELL)
# ═══════════════════════════════════════════════════════════════════════════

def plot_f8():
    """F8: BUY/SELL accuracy decomposition (human vs LLM, N=76 paired direction events)."""
    # From human_vs_llm_direction_decomposition.csv
    labels = ["Human\nBUY", "Human\nSELL", "LLM\nBUY", "LLM\nSELL"]
    accs = [50.9, 73.9, 55.6, 65.0]
    ns = [53, 23, 36, 40]
    correct = [27, 17, 20, 26]
    base_buy = 43.4
    base_sell = 56.6

    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.65))

    x = np.arange(4)
    colors = [NAVY, NAVY, RED, RED]
    alphas = [0.6, 0.9, 0.6, 0.9]

    for i in range(4):
        ax.bar(x[i], accs[i], 0.55, color=colors[i], alpha=alphas[i])
        ax.text(x[i], accs[i] + 2, f"{correct[i]}/{ns[i]}\n{accs[i]:.1f}%",
                ha="center", fontsize=7, fontweight="bold")

    ax.axhline(50, color=GREY, ls="--", lw=0.7, label="50% (coin flip)")
    ax.axhline(base_buy, color=GOLD, ls=":", lw=0.8, label=f"BUY base rate {base_buy}%")
    ax.axhline(base_sell, color=GREEN, ls=":", lw=0.8, label=f"SELL base rate {base_sell}%")

    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_ylabel("Sign accuracy (%)")
    ax.set_ylim(0, 90)
    ax.legend(loc="upper left", fontsize=6.5)
    ax.set_title("Figure 8: BUY vs SELL accuracy (N = 76 paired direction events)\nNo ±2% band — sign accuracy only",
                 fontsize=9, fontweight="bold")

    save(fig, "F8_buy_sell_asymmetry")


# ═══════════════════════════════════════════════════════════════════════════
# F9: SECTION ABLATION (cost per correct vs accuracy + agreement)
# ═══════════════════════════════════════════════════════════════════════════

def plot_f9():
    """F9: Section ablation — accuracy, cost per correct, and agreement."""
    arms = ["Full bundle", "Press release", "Prepared\nremarks", "Q&A only"]
    accs = [68.1, 64.9, 63.4, 68.4]
    cost_per_correct = [0.0358, 0.0225, 0.0208, 0.0229]
    n_graded = [47, 37, 41, 38]
    n_correct = [32, 24, 26, 26]
    agreement = [100.0, 72.3, 85.7, 71.4]  # % agreement with full bundle
    # MDE band for paired comparison
    mde_pp = 12.0

    fig, ax1 = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.75))
    ax2 = ax1.twinx()

    x = np.arange(4)
    w = 0.35

    # Accuracy bars
    bars = ax1.bar(x - w/2, accs, w, color=NAVY, alpha=0.8, label="Accuracy (%)")

    # MDE band around full_bundle accuracy
    ax1.fill_between([-0.5, 3.5], [68.1 - mde_pp]*2, [68.1 + mde_pp]*2,
                     color=LTGREY, alpha=0.2, label=f"±{mde_pp:.0f}pp MDE")

    # Cost per correct (right axis)
    ax2.bar(x + w/2, [c * 100 for c in cost_per_correct], w,
            color=RED, alpha=0.6, label="¢ / correct call")
    ax2.set_ylabel("Cost per correct call (¢)", color=RED)

    # Annotate
    for i in range(4):
        ax1.text(x[i] - w/2, accs[i] + 1, f"{n_correct[i]}/{n_graded[i]}\n{accs[i]:.1f}%",
                ha="center", fontsize=6.5, color=NAVY)
        ax2.text(x[i] + w/2, cost_per_correct[i] * 100 + 0.2,
                f"{cost_per_correct[i]*100:.1f}¢", ha="center", fontsize=6.5, color=RED)
        # Agreement annotation below x-axis
        ax1.text(x[i], -6, f"agr: {agreement[i]:.0f}%", ha="center",
                fontsize=6.5, color=GREY)

    ax1.set_xticks(x)
    ax1.set_xticklabels(arms, fontsize=8)
    ax1.set_ylabel("Selectivity accuracy (%)", color=NAVY)
    ax1.set_ylim(-10, 90)
    ax2.set_ylim(0, 5)
    ax1.set_title("Figure 9: Section ablation (N = 119 paired events)\nAccuracy, cost, and signal agreement with full bundle",
                  fontsize=9, fontweight="bold")
    ax1.text(0.5, -0.2, "Paired n: press 45, prepared 53, Q&A 43 (strict); all diffs inside MDE",
             transform=ax1.transAxes, ha="center", fontsize=6, color=GREY, style="italic")

    save(fig, "F9_section_ablation")


# ═══════════════════════════════════════════════════════════════════════════
# F10: LATENCY DISTRIBUTION (from JSONL logs)
# ═══════════════════════════════════════════════════════════════════════════

def plot_f10():
    """F10: Latency distribution from first_run_costs.jsonl logs."""
    latencies = load_latency_jsonl()

    if len(latencies) == 0:
        print("  ✗ F10: no latency data found")
        return

    # Clip for display (exclude extreme outliers for hist but note them)
    clip = 60  # seconds
    clipped = latencies[latencies <= clip]
    n_outliers = len(latencies) - len(clipped)

    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.7))

    bins = np.arange(0, clip + 2, 2)
    ax.hist(clipped, bins=bins, color=NAVY, alpha=0.8, edgecolor="white", lw=0.3)

    med = np.median(latencies)
    mean = np.mean(latencies)
    q1, q3 = np.percentile(latencies, [25, 75])

    ax.axvline(med, color=RED, ls="--", lw=1.2, label=f"Median = {med:.1f}s")
    ax.axvline(mean, color=GOLD, ls="-.", lw=1.2, label=f"Mean = {mean:.1f}s")

    ax.set_xlabel("Latency (seconds)")
    ax.set_ylabel("Count")
    ax.legend(loc="upper right", fontsize=7)

    stats_text = (f"n = {len(latencies)} calls\n"
                  f"Q1 = {q1:.1f}s, Q3 = {q3:.1f}s\n"
                  f"IQR = {q3-q1:.1f}s")
    if n_outliers > 0:
        stats_text += f"\n{n_outliers} calls > {clip}s (not shown)"
    ax.text(0.97, 0.70, stats_text, transform=ax.transAxes, fontsize=7,
            ha="right", va="top", color=GREY,
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor=LTGREY, alpha=0.8))

    ax.set_title(f"Figure 10: Micro-layer call latency (n = {len(latencies)})",
                 fontsize=10, fontweight="bold")

    save(fig, "F10_latency_distribution")


# ═══════════════════════════════════════════════════════════════════════════
# F12: CONFUSION MATRIX (human vs LLM, 3x3)
# ═══════════════════════════════════════════════════════════════════════════

def plot_f12():
    """F12: 3×3 confusion matrix, human vs LLM (N=171, kappa=0.109)."""
    # From kappa_near_independence.csv
    matrix = np.array([
        [32, 43, 21],  # Human BUY
        [ 6, 14, 20],  # Human HOLD
        [ 4, 12, 19],  # Human SELL
    ])

    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.8))

    # Heatmap
    im = ax.imshow(matrix, cmap="Blues", aspect="auto")

    labels_h = ["BUY", "HOLD", "SELL"]
    labels_l = ["BUY", "HOLD", "SELL"]

    ax.set_xticks(range(3))
    ax.set_xticklabels(labels_l)
    ax.set_yticks(range(3))
    ax.set_yticklabels(labels_h)
    ax.set_xlabel("LLM decision")
    ax.set_ylabel("Human decision")

    # Annotate cells
    for i in range(3):
        for j in range(3):
            val = matrix[i, j]
            pct = val / 171 * 100
            color = "white" if val > 30 else "black"
            ax.text(j, i, f"{val}\n({pct:.0f}%)", ha="center", va="center",
                    fontsize=9, color=color, fontweight="bold")

    # Row and column totals
    for i in range(3):
        ax.text(3.3, i, f"{matrix[i,:].sum()}", ha="center", va="center",
                fontsize=8, color=GREY)
    for j in range(3):
        ax.text(j, 3.3, f"{matrix[:,j].sum()}", ha="center", va="center",
                fontsize=8, color=GREY)

    ax.set_title("Figure 12: Human vs LLM confusion matrix\n(N = 171 paired events, κ = 0.109, 90% CI [0.030, 0.190])",
                 fontsize=9, fontweight="bold")

    save(fig, "F12_confusion_matrix")


# ═══════════════════════════════════════════════════════════════════════════
# F13: ACCURACY BY MOVE MAGNITUDE
# ═══════════════════════════════════════════════════════════════════════════

def plot_f13():
    """F13: Accuracy by move magnitude (3 buckets: 2-5%, 5-10%, >10%)."""
    ret_rows = load_returns_matrix()
    cal_rows = load_calibration_csv()
    events = clean_universe(ret_rows, cal_rows)

    buckets = [(0.02, 0.05, "2–5%"), (0.05, 0.10, "5–10%"), (0.10, 1.0, ">10%")]

    results = []
    for lo, hi, label in buckets:
        n_graded = 0
        n_correct = 0
        for e in events:
            signal = e.get("blend_predicted_signal_default", "HOLD")
            if signal == "HOLD":
                continue
            ret = float(e["ret_overnight"])
            abs_ret = abs(ret)
            if abs_ret > lo and (abs_ret <= hi if hi < 1.0 else True):
                n_graded += 1
                if (signal == "BUY" and ret > 0) or (signal == "SELL" and ret < 0):
                    n_correct += 1
        acc = n_correct / n_graded * 100 if n_graded > 0 else 0
        results.append((label, n_graded, n_correct, acc))

    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.6))

    x = np.arange(len(results))
    labels = [r[0] for r in results]
    accs = [r[3] for r in results]
    ns = [r[1] for r in results]
    corrects = [r[2] for r in results]

    colors = [NAVY, NAVY, NAVY]
    # Flag the smallest bucket
    if ns[-1] < 20:
        colors[-1] = GREY  # flag as underpowered

    bars = ax.bar(x, accs, 0.5, color=colors, alpha=0.8)

    for i in range(len(results)):
        flag = " *" if ns[i] < 20 else ""
        ax.text(x[i], accs[i] + 2, f"{corrects[i]}/{ns[i]}{flag}\n{accs[i]:.1f}%",
                ha="center", fontsize=8, fontweight="bold")

    ax.axhline(50, color=GREY, ls="--", lw=0.7, label="50% baseline")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=9)
    ax.set_xlabel("Absolute overnight return")
    ax.set_ylabel("Directional accuracy (%)")
    ax.set_ylim(0, 90)
    ax.legend(loc="lower right", fontsize=7)
    ax.set_title("Figure 13: Accuracy by move magnitude (N = 233 traded+graded)",
                 fontsize=9, fontweight="bold")
    if ns[-1] < 20:
        ax.text(0.5, -0.12, f"* >10% bucket: n = {ns[-1]} (interpret with caution)",
                transform=ax.transAxes, ha="center", fontsize=7, color=RED, style="italic")

    save(fig, "F13_accuracy_by_magnitude")


# ═══════════════════════════════════════════════════════════════════════════
# F11: BLENDED SCORE VS OVERNIGHT RETURN SCATTER
# ═══════════════════════════════════════════════════════════════════════════

def plot_f11():
    """F11: Blended score vs overnight return scatter (N=233).
    Blended score recomputed via blend.blend_scores() with DEFAULT_WEIGHTS,
    identical to holding_period_curve.py (verified: reproduces rho=0.236 exactly).
    """
    from blend import blend_scores, DEFAULT_WEIGHTS
    from scipy.stats import spearmanr

    ret_rows = load_returns_matrix()
    cal_rows = load_calibration_csv()
    excluded_ws = load_excluded_ids()
    cal_map = {r["document_id"]: r for r in cal_rows}

    scores, rets, signals = [], [], []
    for r in ret_rows:
        doc = r["document_id"]
        if r.get("timing_excluded", "NO") == "YES": continue
        if doc in excluded_ws: continue
        if doc == "SPOT_FQ1_2026": continue
        if doc not in cal_map: continue

        c = cal_map[doc]
        micro_s = c.get("micro_score", "")
        macro_s = c.get("macro_score", "")
        if not micro_s:
            continue
        micro = float(micro_s)
        macro = float(macro_s) if macro_s else None

        blended = blend_scores(micro, macro, None, None, DEFAULT_WEIGHTS)
        ret = float(r["ret_overnight"])
        signal = c.get("blend_predicted_signal_default", "HOLD")

        scores.append(blended)
        rets.append(ret * 100)
        signals.append(signal)

    scores = np.array(scores)
    rets = np.array(rets)

    # Verify rho
    rho, p = spearmanr(scores, rets)
    assert abs(rho - 0.23600083738353303) < 1e-8, f"rho mismatch: {rho}"

    fig, ax = plt.subplots(figsize=(FIG_WIDTH, FIG_WIDTH * 0.85))

    # Color by signal
    colors_map = {"BUY": NAVY, "SELL": RED, "HOLD": GREY}
    for sig_val in ["HOLD", "BUY", "SELL"]:
        mask = np.array([s == sig_val for s in signals])
        ax.scatter(scores[mask], rets[mask], c=colors_map[sig_val], s=12,
                   alpha=0.5, label=sig_val, edgecolors="none")

    ax.axhline(0, color=GREY, lw=0.5, ls="--")
    ax.axvline(0, color=GREY, lw=0.5, ls="--")

    # HOLD band lines
    ax.axhline(2, color=LTGREY, lw=0.5, ls=":")
    ax.axhline(-2, color=LTGREY, lw=0.5, ls=":")
    ax.text(0.72, 2.5, "±2% band", fontsize=6.5, color=LTGREY, transform=ax.get_yaxis_transform())

    # OLS trend line for visual reference
    z = np.polyfit(scores, rets, 1)
    x_line = np.linspace(scores.min(), scores.max(), 100)
    ax.plot(x_line, np.polyval(z, x_line), color=GOLD, lw=1.2, ls="--", alpha=0.7)

    ax.set_xlabel("Blended score (recomputed via blend_scores())")
    ax.set_ylabel("Overnight return (%)")
    ax.legend(loc="upper left", fontsize=7, framealpha=0.8)

    rho_text = (f"Spearman ρ = {rho:.3f}  (p = {p:.4f})\n"
                f"n = {len(scores)}\n"
                f"Score recomputed in plot script\nvia blend.blend_scores()")
    ax.text(0.97, 0.03, rho_text, transform=ax.transAxes, fontsize=6.5,
            ha="right", va="bottom", color=GREY,
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor=LTGREY, alpha=0.8))

    ax.set_title("Figure 11: Blended score vs overnight return (N = 233)",
                 fontsize=10, fontweight="bold")

    save(fig, "F11_score_vs_return")


# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("Generating figures...")
    plot_f1()
    plot_f2()
    plot_f3()
    plot_f4()
    plot_f5()
    plot_f6()
    plot_f7()
    plot_f8()
    plot_f9()
    plot_f10()
    plot_f11()
    plot_f12()
    plot_f13()
    print("\nDone. All outputs in figures/")
